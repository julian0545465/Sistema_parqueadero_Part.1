<center>
<header>
        <nav>
			<a href="home">Inicio</a>
			<a href="Registrar">Registrarse</a>
            <a href="news">Catalogo</a>  
            <a href="Contactanos">Contactanos</a>  

        </nav>
    </header>
    <br>

    <div class="login-box">
        <strong><h2>Iniciar Sesión</h2></strong>
        <form>
            <div class="user-box">
                <input type="text">
                <label>Usuario</label>
            </div>
            <div class="user-box">
                <input type="password" name="" id="">
                <label>Contraseña</label>
            </div>
           <center><a href="#">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            Iniciar Sesión
        </a></center>
      
        </form>

    </div>
	</center>