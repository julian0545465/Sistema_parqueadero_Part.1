
<center>
<header>
        <nav>
			<a href="home">Inicio</a>
            <a href="Login">Iniciar Sesión</a>
            <a href="news">Catalogo</a>  
            <a href="Contactanos">Contactanos</a>  


        </nav>
    </header>
    <br>
    <br>
    <br>
    <br>
    <br>
    <br>


    <div class="login-box">
        <strong><h2>Registrate</h2></strong>
        <form>
            <div class="user-box">
                <input type="text">
                <label>Cedula</label>
            </div>
            <div class="user-box">
                <input type="text" name="" id="">
                <label>Nombre Completo</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Número de celular</label>
            </div>
            <div class="user-box">
                <input type="text" name="" id="">
                <label>Dirrección</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Correo Electronico</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Usuario</label>
            </div>
            <div class="user-box">
                <input type="text" name="" id="">
                <label>Contraseña</label>
            </div>
           <center><a href="#">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            Registrar
        </form>

    </div>
	
</center>
</body>
</html>
