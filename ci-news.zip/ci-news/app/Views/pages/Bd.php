<!-- create database ci4tutorial ;
use ci4tutorial ;

CREATE TABLE news (
  `IdProducto` int(11) UNSIGNED NOT NULL,
  `Nombres` varchar(244) DEFAULT NULL,
  `Descripcion` varchar(244) DEFAULT NULL,
  `Precio` double DEFAULT NULL,
  `Stock` int(11) UNSIGNED DEFAULT NULL,
  `Estado` varchar(1) DEFAULT NULL
) ;

INSERT INTO `news` (`IdProducto`, `Nombres`, `Descripcion`, `Precio`, `Stock`, `Estado`) VALUES
(1, 'Teclado', 'Logitech 345 Editado', 150, 99, '1'),
(2, 'Mouse' ,'Logitech 567', 20, 98, '1'),
(3, 'Laptop', 'Lenovo Ideapad 520', 800, 100, '1'),
(4, 'HeadPhones','Sony M333', 500, 98, '1');
 -->
