<center>
<header>
        <nav>
			<a href="home">Inicio</a>
            <a href="Login">Iniciar Sesión</a>
			<a href="Registrar">Registrarse</a>
            <a href="news">Catalogo</a>  
           

        </nav>
    </header>
    <br>

    
    <div class="login-box">
        <strong><h2>Contactanos</h2></strong>
        <form>
            <div class="user-box">
                <input type="text" name="" id="">
                <label>Nombre Completo</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Número de celular</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Correo Electronico</label>
            </div>
            <div class="user-box">
                <input type="text">
                <label>Mensaje</label>
            </div>
    
           <center><a href="#">
            <span></span>
            <span></span>
            <span></span>
            <span></span>
            Enviar
        </form>

    </div>
	
</center>
</body>
</html>
