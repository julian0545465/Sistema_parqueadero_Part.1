<header>
        <nav>
		<a href="Login">Iniciar Sesión</a>
        <a href="Registrar">Registrarse</a>
		<a href="news">Catalogo</a>  
        <a href="Contactanos">Contactanos</a>  
        </nav>
    </header>
    <br>
    <div class="encabezado">
        <img src="IMG/images (1).jpg" alt="" height="700" width="450">
        <p>Empresa de equipos informaticos</p>
        <h1>Outek</h1>
        <p>Technology Check-Out empresa dedicada a la importación, montaje y distribución de Equipos de Cómputo en la ciudad de Bogotá D.C.</p>
    </div>



