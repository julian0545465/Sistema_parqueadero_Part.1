
<header>
        <nav>
			<a href="home">Inicio</a>
            <a href="Login">Iniciar Sesión</a>
			<a href="Registrar">Registrarse</a>
            <a href="Contactanos">Contactanos</a>
           
            
        </nav>
    </header>
    <br>
    <br>
    <br>



    
<h1 align="center">CATALOGO</h1>
<div class="border"></div>
<br>

<?php if (! empty($news) && is_array($news)): ?>
<?php foreach ($news as $news_item): ?>
<div class="testimonials">
<div class="inner">
        <div class="row">
            <div class="col">
                <div class="testimonial">
                    <img src="" alt="">
                    <h3><?= esc($news_item['Nombres']) ?></h3>
                    <div class="starts">
                        <i class="fas fa-start"></i>
                        <i class="fas fa-start"></i>
                        <i class="fas fa-start"></i>
                        <i class="fas fa-start"></i>
                        <i class="fas fa-start"></i>
                    </div>
                  
                    <p><?= esc($news_item['Descripcion']) ?></p>
                    <br>
                    <center><a href="">
                        <span></span>
                        <span></span>
                        <span></span>
                        <span></span>
                        COMPRAR
                    </a></center>
             
                </div>
            </div>
        </div>
        </div>
</div>

<?php endforeach ?>
<?php else: ?>

<h3>No News</h3>

<p>Unable to find any news for you.</p>

<?php endif ?>



<!-- 
Base de datos


create database ci4tutorial ;
use ci4tutorial ;

CREATE TABLE news (
  `IdProducto` int(11) UNSIGNED NOT NULL,
  `Nombres` varchar(244) DEFAULT NULL,
  `Descripcion` varchar(244) DEFAULT NULL,
  `Precio` double DEFAULT NULL,
  `Stock` int(11) UNSIGNED DEFAULT NULL,
  `Estado` varchar(1) DEFAULT NULL
) ;

INSERT INTO `news` (`IdProducto`, `Nombres`, `Descripcion`, `Precio`, `Stock`, `Estado`) VALUES
(1, 'Teclado', 'Logitech 345 Editado', 150, 99, '1'),
(2, 'Mouse' ,'Logitech 567', 20, 98, '1'),
(3, 'Laptop', 'Lenovo Ideapad 520', 800, 100, '1'),
(4, 'HeadPhones','Sony M333', 500, 98, '1'); -->


